package doubledispatch;

public class Rectangle extends Shape {
    Integer length, width;
    private static final String NAME = "Rectangle";

    Rectangle(Integer l, Integer w) {
        super(NAME);
        length = l;
        width = w;
    }

    void accept(Artist a) {
        a.draw(this);
    }
    
    
}



