package doubledispatch;

public class Shape {
    String ident;

    Shape(String shapeName) {
        this.ident = shapeName;
    } 

    void accept(Artist a) {
        a.draw(this);
    }


}
