package doubledispatch;

public class Artist {

    public void draw(Shape s) {
        System.out.printf("GENERIC\tDrawing %s, class %s\n", s.ident, s.getClass().getSimpleName());
    }

    public void draw(Rectangle s) {
        System.out.printf("RECTANGLE\tDrawing %s, class %s\tLength: %d, Width: %d\n", 
            s.ident, 
            s.getClass().getSimpleName(),
            s.length,
            s.width
        );
    }

    public void draw(Circle s) {
        System.out.printf("CIRCLE   \tDrawing %s, class %s\tRadius: %d, Center: %d\n", 
            s.ident, 
            s.getClass().getSimpleName(),
            s.radius,
            s.center
        );
    }

    public void draw(Triangle s) {
        System.out.printf("TRIANGLE\tDrawing %s, class %s\tBase: %d, Height: %d\n", 
            s.ident, 
            s.getClass().getSimpleName(),
            s.base,
            s.height
        );
    }

}
