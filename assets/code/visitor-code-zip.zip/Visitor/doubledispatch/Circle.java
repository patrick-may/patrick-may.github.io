package doubledispatch;


public class Circle extends Shape {
    Integer radius, center;
    private static final String NAME = "Circle";
    
    Circle(Integer r, Integer c) {
        super(NAME);
        radius = r;
        center = c;
    }

    void accept(Artist a) {
        a.draw(this);
    }

    
} 
