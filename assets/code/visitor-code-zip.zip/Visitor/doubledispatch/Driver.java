package doubledispatch;

import java.util.ArrayList;
import java.util.List;

public class Driver { 
    
    public static void main(String[] args) {
        runCode();             
    }


    static void runCode() {
        // making heterogenous collection
        List<Shape> images = new ArrayList<Shape>();
        images.add(new Circle(10, 5));
        images.add(new Rectangle(3, 4));
        images.add(new Triangle(4, 34));
        images.add(new Circle(2, 17));
        images.add(new Rectangle(7, 1));
        images.add(new Triangle(8, 9));
        images.add(new Rectangle(6, 9));
        images.add(new Circle(4, 15));
        
        // double dispatch, properly functional
        Artist betterVisitor = new Artist();
        images.forEach((Shape s) -> s.accept(betterVisitor));
        
        //for(Shape s : images) {
        //    s.accept(betterVisitor);
        //}
    }
}
