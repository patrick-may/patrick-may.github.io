package novisitor;

public class InstanceArtist {
    public void draw(Shape s) {
        System.out.println("GENERIC\tPerforming instance logic...");
        if (s instanceof Rectangle) {
            drawRectangle((Rectangle) s);
        }
        else if (s instanceof Circle) {
            drawCircle((Circle) s);
        }
        else if (s instanceof Triangle) {
            drawTriangle((Triangle) s);
        }
        else {
            //...
        }
    }

    public void drawRectangle(Rectangle s) {
        System.out.printf("RECTANGLE\tDrawing %s, class %s\tLength: %d, Width: %d\n", 
            s.ident, 
            s.getClass().getSimpleName(),
            s.length,
            s.width
        );
    }

    public void drawCircle(Circle s) {
        System.out.printf("CIRCLE   \tDrawing %s, class %s\tRadius: %d, Center: %d\n", 
            s.ident, 
            s.getClass().getSimpleName(),
            s.radius,
            s.center
        );
    }

    public void drawTriangle(Triangle s) {
        System.out.printf("TRIANGLE\tDrawing %s, class %s\tBase: %d, Height: %d\n", 
            s.ident, 
            s.getClass().getSimpleName(),
            s.base,
            s.height
        );
    }
}
