package novisitor;

public class Triangle extends Shape {
    private static final String NAME = "Triangle";
    Integer base, height;

    Triangle(Integer b, Integer h) {
        super(NAME);
        this.base = b;
        this.height = h;
    }
}
