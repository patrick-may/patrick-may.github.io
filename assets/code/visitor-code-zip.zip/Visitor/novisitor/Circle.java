package novisitor;


public class Circle extends Shape {
    Integer radius, center;
    private static final String NAME = "Circle";
    
    Circle(Integer r, Integer c) {
        super(NAME);
        radius = r;
        center = c;
    }

    
} 
