package novisitor;

public class Shape {
    String ident;

    Shape(String shapeName) {
        this.ident = shapeName;
    } 


}
